<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'localhost';
$config['smtp_port'] = 25;
$config['smtp_user'] = 'info@businessphix.com';
$config['smtp_pass'] = 'SIM6hCDF';
$config['mailtype'] = 'html';

